package com.adnantjeexx.taxiappriders;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
