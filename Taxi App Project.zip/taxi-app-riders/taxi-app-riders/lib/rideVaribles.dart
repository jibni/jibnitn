
int driverRequestTimeout = 30;

String status = '';

String driverCarDetails = '';

String driverFullName = '';
String driverPhotoProfile = '';
String driverID = '';

String driverPhoneNumber;

String tripStatusDisplay = 'Driver is Arriving';
