

import 'dart:io';
import 'dart:async';
import 'package:path/path.dart';
import 'package:cab_rider/datamodels/FavoriteAddress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper{
  static Database _db;
  final String addressTable = 'addressTable';
  final String columnId = 'id';
  final String columnPlaceName = 'placeName';
  final String columnLatitude = 'latitude';
  final String columnLongitude = 'longitude';
  final String columnPlaceId = 'placeId';
  final String columnFavAddressName = 'favAddressName';


  Future<Database> get db async{
    if(_db != null){
      return _db;
    }
    _db = await initDB();
    return _db;
  }


  initDB() async{
    Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path , 'mydb.db');
    var myOwnDB = await openDatabase(path,version: 1,
        onCreate: _onCreate);
    return myOwnDB;
  }

  void _onCreate(Database db , int newVersion) async{
    var sql = "CREATE TABLE $addressTable ($columnId INTEGER PRIMARY KEY,"
        " $columnFavAddressName TEXT, $columnPlaceName TEXT, $columnLatitude DOUBLE,  $columnLongitude DOUBLE, $columnPlaceId TEXT )";
    await db.execute(sql);
  }

  Future<int> saveFavoriteAddress(FavoriteAddress favoriteAddress) async{
    var dbClient = await  db;
    int result = await dbClient.insert("$addressTable", favoriteAddress.toMap());
    return result;
  }


  Future<List> getAllFavoriteAddress() async{
    var dbClient = await  db;
    var sql = "SELECT * FROM $addressTable";
    List result = await dbClient.rawQuery(sql);
    return result.toList();
  }

  Future<int> getCount() async{
    var dbClient = await  db;
    var sql = "SELECT COUNT(*) FROM $addressTable";
    return  Sqflite.firstIntValue(await dbClient.rawQuery(sql)) ;
  }

  Future<FavoriteAddress> getFavoriteAddress(int id) async{
    var dbClient = await  db;
    var sql = "SELECT * FROM $addressTable WHERE $columnId = $id";
    var result = await dbClient.rawQuery(sql);
    if(result.length == 0) return null;
    return  new FavoriteAddress.fromMap(result.first) ;
  }


  Future<int> deleteAddress(int id) async{
    var dbClient = await  db;
    return  await dbClient.delete(
        addressTable , where: "$columnId = ?" , whereArgs: [id]
    );
  }

  Future<int> deleteAllAddress() async{
    var dbClient = await  db;
    return  await dbClient.delete(addressTable);
  }

    Future<int> updateFavoriteAddress(FavoriteAddress favoriteAddress) async{
    var dbClient = await  db;
    return  await dbClient.update(
        addressTable, favoriteAddress.toMap(), where: "$columnId = ?" , whereArgs: [favoriteAddress.id]
    );
  }


  void close() async{
    var dbClient = await  db;
    return  await dbClient.close();
  }


}