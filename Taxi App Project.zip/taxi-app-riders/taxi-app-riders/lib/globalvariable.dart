
import 'package:cab_rider/datamodels/rider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'Theme/Theme.dart';
import 'helpers/helpermethods.dart';


String serverKey = 'key=AAAA_7ihP9Q:APA91bGgn0XILX3GcoknXa_VYp9zs1kY_ujZ0oOn4PrWKLZXYl01NuaXbN1KGSVOTib7SqBDDhORHHLULkQ_fVb3nxwRiUqpnwU4NuEV5mkrwGivUpWsFFzJjA6YKaPu2LJZsb0UmaqO';

String mapKey = 'AIzaSyDu4WqSIFIedm75SbBEI6qQ2czq4r5yO_0';

final CameraPosition googlePlex = CameraPosition(
  target: LatLng(37.42796133580664, -122.085749655962),
  zoom: 14.4746,
);


FirebaseAuth currentFirebaseUser = FirebaseAuth.instance;


 Rider currentRiderInfo;

 int fares;

