
import 'package:firebase_database/firebase_database.dart';

class Rider {

   String phoneNumber;

  Rider({ this.phoneNumber});

  Rider.fromSnapshot(DataSnapshot snapshot){
    phoneNumber = snapshot.value['phone']['phoneNumber'];
  }
}