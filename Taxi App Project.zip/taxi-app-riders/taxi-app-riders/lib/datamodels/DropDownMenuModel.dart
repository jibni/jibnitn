
class DropDownMenuModel {
  final String personNumber;
  DropDownMenuModel({
     this.personNumber,
  });
}