class NearbyDriver{
  String key;
  double latitude;
  double longitude;

  NearbyDriver({
     this.key,
     this.latitude,
     this.longitude,
});

}