
class FavoriteAddress{

   String favAddressName;
   String placeName;
   double latitude;
   double longitude;
   String placeId;
   int id;


  FavoriteAddress({ this.favAddressName,  this.placeName,  this.latitude,
     this.longitude,  this.placeId,  this.id});

  FavoriteAddress.map(dynamic obj){
    this.favAddressName = obj['favAddressName'];
    this.placeName = obj['placeName'];
    this.latitude = obj['latitude'];
    this.longitude = obj['longitude'];
    this.placeId = obj['placeId'];
    this.id = obj['id'];
  }

  String get _favAddressName => favAddressName;
  String get _placeName => placeName;
  double get _latitude => latitude;
  double get _longitude => longitude;
  String get _placeId => placeId;
  int get _id => id;

  Map<String , dynamic> toMap(){
    var map = new Map<String , dynamic>();
    map['favAddressName'] = _favAddressName;
    map['placeName'] = _placeName;
    map['latitude'] = _latitude;
    map['longitude'] = _longitude;
    map['placeId'] = _placeId;
    if(id != null){
      map['id'] = _id;
    }
    return map;
  }

  FavoriteAddress.fromMap(Map<String , dynamic>map){
    this.favAddressName = map['favAddressName'];
    this.placeName = map['placeName'];
    this.latitude = map['latitude'];
    this.longitude = map['longitude'];
    this.placeId = map['placeId'];
    this.id = map['id'];
  }


}