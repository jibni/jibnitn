import 'package:cab_rider/Theme/Theme.dart';
import 'package:cab_rider/dataprovider/appdata.dart';
import 'package:cab_rider/screens/AddFavoriteAddressPage.dart';
import 'package:cab_rider/screens/FavoriteAddressPage.dart';
import 'package:cab_rider/screens/AddPhoneNumPage.dart';
import 'package:cab_rider/screens/ContactUsPage.dart';
import 'package:cab_rider/screens/HowItWorksPage.dart';
import 'package:cab_rider/screens/MapPage.dart';
import 'package:cab_rider/screens/MyTripsPage.dart';
import 'package:cab_rider/screens/SplashScreen.dart';
import 'package:cab_rider/screens/UpdateFavoriteAddress.dart';
import 'package:cab_rider/screens/searchpage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'globalvariable.dart';
import 'screens/AboutUsPage.dart';

// remember me sign in
bool isLoggedIn = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

  runApp(
      MultiProvider(
        providers: [

          ChangeNotifierProvider<AppData>(
            create: (context) => AppData(),
          ),
        ],
        child: ChangeNotifierProvider(
            create: (context) =>
                ThemeProvider(
                  // check Theme Mode if is Dark or Light
                    isDarkMode: sharedPreferences.getBool("isDarkTheme")
                ),
            child: MyApp()
        ),
      )

  );

}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.


  @override
  Widget build(BuildContext context) {


    // disable Orientation Screen
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown
    ]);


    return Consumer<ThemeProvider>(
        builder: (context, themProvider, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: themProvider.getTheme,
            initialRoute: currentFirebaseUser.currentUser?.uid == null ? SplashScreen.id : MapPage.id, // check if user signed out or not
            routes: {
              MapPage.id: (context) => MapPage(),
              SplashScreen.id: (context) => SplashScreen(),
              SearchPage.id: (context) => SearchPage(),
              AddPhoneNumPage.id: (context) => AddPhoneNumPage(),
              MyTripsPage.id: (context) => MyTripsPage(),
              ContactUsPage.id: (context) => ContactUsPage(),
              HowItWorkPage.id: (context) => HowItWorkPage(),
              AboutUsPage.id: (context) => AboutUsPage(),
              FavoriteAddressPage.id: (context) => FavoriteAddressPage(),
              AddFavoriteAddressPage.id: (context) => AddFavoriteAddressPage(),
              UpdateFavoriteAddress.id: (context) => UpdateFavoriteAddress(),
            },
          );
        }
      );

  }
}

