import 'package:cab_rider/TaxiApp_Icons/TaxiApp_Icons.dart';
import 'package:cab_rider/Taxi_App_Color.dart';
import 'package:cab_rider/Theme/Theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NoDriverDialog extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    ThemeProvider themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      elevation: 0.0,
      child: Container(
        margin: EdgeInsets.all(0),
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
        ),
        child: Padding(
          padding:  EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 10,),

                Text('No driver found',
                  style: TextStyle(
                      fontSize: 22.0,
                    fontWeight: FontWeight.bold
                  ),
                ),

                SizedBox(height: 25,),

                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    'No available driver close by, we suggest you try again shortly',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.lato(
                      color: TaxiAppColor.colorGrey
                    ),
                  ),
                ),

                SizedBox(height: 30,),

                GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                  child: Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        width: 2,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                            cancel, height: 20,width: 20,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        ),
                        SizedBox(width: 10,),
                        Text(
                          "Close",
                          style: GoogleFonts.lato(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 10,),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
