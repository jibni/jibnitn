import 'package:cab_rider/Theme/Theme.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../Taxi_App_Color.dart';

class BrandDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    ThemeProvider themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    return Divider(
      height: 1.0,
      color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkTextField : TaxiAppColor.colorGreyLite,
      thickness: 1.0,);
  }
}
