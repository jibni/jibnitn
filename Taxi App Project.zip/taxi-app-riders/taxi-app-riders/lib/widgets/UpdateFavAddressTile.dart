import 'package:cab_rider/TaxiApp_Icons/TaxiApp_Icons.dart';
import 'package:cab_rider/Taxi_App_Color.dart';
import 'package:cab_rider/Theme/Theme.dart';
import 'package:cab_rider/datamodels/FavoriteAddress.dart';
import 'package:cab_rider/datamodels/address.dart';
import 'package:cab_rider/datamodels/prediction.dart';
import 'package:cab_rider/dataprovider/appdata.dart';
import 'package:cab_rider/globalvariable.dart';
import 'package:cab_rider/helpers/requesthelper.dart';
import 'package:cab_rider/sqfLite/DatabaseHelper.dart';
import 'package:cab_rider/widgets/ProgressDialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class UpdateFavAddressTile extends StatefulWidget {

  final Prediction prediction;
  String favAddressName;
  int favAddressId;
  UpdateFavAddressTile({ this.prediction,  this.favAddressName,  this.favAddressId});

  @override
  _UpdateFavAddressTileState createState() => _UpdateFavAddressTileState();
}

class _UpdateFavAddressTileState extends State<UpdateFavAddressTile> {

   DatabaseHelper db;

  @override
  void initState() {
    // TODO: implement initState
    db = new DatabaseHelper();
    super.initState();
  }

  void getPlaceDetails(String placeID, context) async {


    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => ProgressDialog(status: 'Please wait...',)
    );

    String url = 'https://maps.googleapis.com/maps/api/place/details/json?placeid=$placeID&key=$mapKey';

    var response = await RequestHelper.getRequest(url);

    Navigator.pop(context);

    if(response == 'failed'){
      return;
    }

    if(response['status'] == 'OK'){



      FavoriteAddress favPlace = FavoriteAddress(placeName: '', longitude: 0, id: 0, latitude: 0, favAddressName: '', placeId: '');
      favPlace.placeName = response['result']['name'];
      favPlace.placeId = placeID;
      favPlace.latitude = response ['result']['geometry']['location']['lat'];
      favPlace.longitude = response ['result']['geometry']['location']['lng'];


      FavoriteAddress favoriteAddressMap = FavoriteAddress.fromMap(
          {
            "favAddressName": widget.favAddressName,
            "placeName":favPlace.placeName,
            "latitude":favPlace.latitude,
            "longitude":favPlace.longitude,
            "placeId":favPlace.placeId,
            "id": widget.favAddressId
          }
      );

      await db.updateFavoriteAddress(favoriteAddressMap);
      Navigator.pop(context, "Updated");
    }

  }

  @override
  Widget build(BuildContext context) {

    ThemeProvider themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    // ignore: deprecated_member_use
    return FlatButton(
      onPressed: (){
        getPlaceDetails(widget.prediction.placeId, context);
      },
      padding: EdgeInsets.all(0),
      child: Container(
        child: Column(
          children: <Widget>[
            SizedBox(height: 8,),
            Row(
              children: <Widget>[
                SvgPicture.asset(
                  destIcon,height: 20,width: 20,
                  color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                ),
                SizedBox(width: 12,),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text("${widget.prediction.mainText}", overflow: TextOverflow.ellipsis, style: GoogleFonts.lato(fontSize: 16),),
                      SizedBox(height: 2,),
                      Text("${widget.prediction.secondaryText}", overflow: TextOverflow.ellipsis, style: GoogleFonts.lato(fontSize: 12, color: TaxiAppColor.colorGrey)),
                    ],
                  ),
                )
              ],
            ),
            SizedBox(height: 8,),

          ],
        ),
      ),
    );
  }
}