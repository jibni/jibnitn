import 'package:cab_rider/TaxiApp_Icons/TaxiApp_Icons.dart';
import 'package:cab_rider/Taxi_App_Color.dart';
import 'package:cab_rider/Theme/Theme.dart';
import 'package:cab_rider/datamodels/prediction.dart';
import 'package:cab_rider/dataprovider/appdata.dart';
import 'package:cab_rider/globalvariable.dart';
import 'package:cab_rider/helpers/requesthelper.dart';
import 'package:cab_rider/widgets/BrandDivier.dart';
import 'package:cab_rider/widgets/FavAddressTile.dart';
import 'package:cab_rider/widgets/PredictionTile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:outline_material_icons/outline_material_icons.dart';
import 'package:provider/provider.dart';

class AddFavoriteAddressPage extends StatefulWidget {

  static String id = "AddFavoriteAddressPage";

  @override
  _AddFavoriteAddressPageState createState() => _AddFavoriteAddressPageState();
}

class _AddFavoriteAddressPageState extends State<AddFavoriteAddressPage> {

  var addressName = TextEditingController();
  var destinationController = TextEditingController();

  var focus = FocusNode();

  bool focused = false;

  void setFocus(){
    if(!focused){
      FocusScope.of(context).requestFocus(focus);
      focused = true;
    }
  }

  List<Prediction> destinationPredictionList = [];

  void searchPlace(String placeName) async {

    if(placeName.length > 1){

      String url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$placeName&key=$mapKey&sessiontoken=123254251';
      var response = await RequestHelper.getRequest(url);

      if(response == 'failed'){
        return;
      }

      if(response['status'] == 'OK'){
        var predictionJson = response['predictions'];
        var thisList = (predictionJson as List).map((e) => Prediction.fromJson(e)).toList();

        setState(() {
          destinationPredictionList = thisList;
        });

      }

    }

  }

  @override
  Widget build(BuildContext context) {

    setFocus();

    ThemeProvider themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(
              height: 260,
              decoration: BoxDecoration(
                  color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : TaxiAppColor.colorWhiteBackground,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 5.0,
                      spreadRadius: 0.5,
                      offset: Offset(
                        0.7,
                        0.7,
                      ),
                    ),
                  ]
              ),
              child: Padding(
                padding: EdgeInsets.only(left: 24, top: 48, right: 24, bottom: 20),
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 5,),
                    Row(
                      children: <Widget>[
                        GestureDetector(
                            onTap:(){
                              Navigator.pop(context);
                            },
                            child: Icon(Icons.arrow_back)
                        ),
                        SizedBox(width: 10,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Add Address',
                              style: GoogleFonts.fugazOne(fontSize: 35,),
                            ),
                            Text('Add Favorite Address',
                              style: GoogleFonts.lato(fontSize: 16,),
                            ),
                          ],
                        ),
                      ],
                    ),

                    SizedBox(height: 18,),

                    Row(
                      children: <Widget>[
                        SvgPicture.asset(
                          home, height: 17, width: 17,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        ),

                        SizedBox(width: 18,),

                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Padding(
                              padding:  EdgeInsets.all(2.0),
                              child: TextField(
                                controller: addressName,
                                focusNode: focus,
                                decoration: InputDecoration(
                                  hintText: 'Favorite Address Name',
                                  filled: true,
                                  border: InputBorder.none,
                                  isDense: true,
                                  contentPadding: EdgeInsets.only(left: 10, top: 8, bottom: 8),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),

                    SizedBox(height: 10,),

                    Row(
                      children: <Widget>[
                        SvgPicture.asset(
                          destIcon, height: 20, width: 20,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        ),

                        SizedBox(width: 18,),

                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Padding(
                              padding:  EdgeInsets.all(2.0),
                              child: TextField(
                                onChanged: (value){
                                  searchPlace(value);
                                },
                                controller: destinationController,
                                decoration: InputDecoration(
                                    hintText: 'Address Destination',
                                    filled: true,
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(left: 10, top: 8, bottom: 8)
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),

                  ],
                ),
              ),
            ),

            (destinationPredictionList.length > 0) ?
            Padding(
              padding:  EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ListView.separated(
                padding: EdgeInsets.all(0),
                itemBuilder: (context, index){
                  return FavAddressTile(
                    prediction: destinationPredictionList[index],
                    favAddressName: addressName.text,
                  );
                },
                separatorBuilder: (BuildContext context, int index) => BrandDivider(),
                itemCount: destinationPredictionList.length,
                shrinkWrap: true,
                physics: ClampingScrollPhysics(),
              ),
            )
                : Container(),

          ],
        ),
      ),
    );
  }
}


