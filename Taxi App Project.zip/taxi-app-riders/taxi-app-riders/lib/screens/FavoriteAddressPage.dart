import 'package:cab_rider/TaxiApp_Icons/TaxiApp_Icons.dart';
import 'package:cab_rider/Taxi_App_Color.dart';
import 'package:cab_rider/Theme/Theme.dart';
import 'package:cab_rider/datamodels/FavoriteAddress.dart';
import 'package:cab_rider/datamodels/prediction.dart';
import 'package:cab_rider/dataprovider/appdata.dart';
import 'package:cab_rider/globalvariable.dart';
import 'package:cab_rider/helpers/requesthelper.dart';
import 'package:cab_rider/screens/AddFavoriteAddressPage.dart';
import 'package:cab_rider/screens/UpdateFavoriteAddress.dart';
import 'package:cab_rider/sqfLite/DatabaseHelper.dart';
import 'package:cab_rider/widgets/BrandDivier.dart';
import 'package:cab_rider/widgets/PredictionTile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:outline_material_icons/outline_material_icons.dart';
import 'package:provider/provider.dart';

class FavoriteAddressPage extends StatefulWidget {

  static String id = "FavoriteAddressPage";

  @override
  _FavoriteAddressPageState createState() => _FavoriteAddressPageState();
}

class _FavoriteAddressPageState extends State<FavoriteAddressPage> {

   DatabaseHelper db;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    db = new DatabaseHelper();
    print("initState");
  }

  GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  void showSnackBar(String title) {
    final snackbar = SnackBar(
      content: Text(
        title,
        textAlign: TextAlign.center,
        style: GoogleFonts.lato(
            fontSize: 15
        ),
      ),
      backgroundColor: TaxiAppColor.colorGreen,
    );
    // ignore: deprecated_member_use
    scaffoldKey.currentState.showSnackBar(snackbar);
  }

  @override
  Widget build(BuildContext context) {

    ThemeProvider themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    return Scaffold(
      key: scaffoldKey,
      body: Padding(
        padding: EdgeInsets.only(left: 24, top: 48, right: 24),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: <Widget>[
                    GestureDetector(
                        onTap:(){
                          Navigator.pop(context);
                        },
                        child: Icon(Icons.arrow_back)
                    ),
                    SizedBox(width: 10,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Favorite',
                          style: GoogleFonts.fugazOne(fontSize: 35,),
                        ),
                        Text('Favorite Address',
                          style: GoogleFonts.lato(
                            fontSize: 16,
                            color: TaxiAppColor.colorGrey
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: (){

                    showDialog(
                        context: context,
                        builder: (context) => Dialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          elevation: 0.0,
                          child: Container(
                            margin: EdgeInsets.all(0),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding:  EdgeInsets.all(16.0),
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [

                                    Text('Delete All Address',
                                      style: GoogleFonts.lato(
                                          fontSize: 22.0,
                                          fontWeight: FontWeight.bold
                                      ),
                                    ),
                                    SizedBox(height: 15,),
                                    BrandDivider(),

                                    SizedBox(height: 15,),

                                    Padding(
                                      padding: EdgeInsets.all(8.0),
                                      child: Text(
                                        'are you sure you want to delete All this Address',
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.lato(
                                            color: TaxiAppColor.colorGrey
                                        ),
                                      ),
                                    ),

                                    SizedBox(height: 30,),

                                    GestureDetector(
                                      onTap: (){

                                        // delete All Address in Table
                                        setState(() {
                                          db.deleteAllAddress();
                                          db.close();
                                        });

                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        height: 50,
                                        width: MediaQuery.of(context).size.width,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(8),
                                          border: Border.all(
                                            width: 2,
                                            color: TaxiAppColor.colorPink,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            SvgPicture.asset(
                                                delete, height: 20,width: 20,
                                              color: TaxiAppColor.colorPink,
                                            ),
                                            SizedBox(width: 10,),
                                            Text(
                                              "Delete",
                                              style: GoogleFonts.lato(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                color: TaxiAppColor.colorPink,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),


                                    SizedBox(height: 10,),

                                  ],
                                ),
                              ),
                            ),
                          ),
                        ));

                  },
                    child: SvgPicture.asset(
                      delete, height: 25, width: 25,
                      color: TaxiAppColor.colorPink,
                    )
                )
              ],
            ),
            SizedBox(height: 10,),
            Expanded(
              child: FutureBuilder(
                future: db.getAllFavoriteAddress(),
                builder: (context, AsyncSnapshot snapshot){
                  if(!snapshot.hasData){
                    return Padding(
                      padding: const EdgeInsets.only(top: 80),
                      child: Text(
                        "No Favorite Address yet",
                        style: GoogleFonts.lato(
                          fontSize: 18
                        ),
                      ),
                    );
                  } else{
                    return ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (context, int index){
                          FavoriteAddress favAddress = FavoriteAddress.fromMap(snapshot.data[index]);
                          return Container(
                              padding: EdgeInsets.all(15),
                              margin: EdgeInsets.only(bottom: 15),
                              decoration: BoxDecoration(
                                  color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.black26.withOpacity(0.1),
                                        blurRadius: 5.0,
                                        spreadRadius: 0.5,
                                        offset: Offset(
                                          0.7,
                                          0.7,
                                        ))
                                  ]),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      SvgPicture.asset(
                                        destIcon, height: 25,width: 25,
                                        color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                      ),
                                      SizedBox(
                                        width: 15,
                                      ),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "${favAddress.favAddressName}",
                                            style: GoogleFonts.lato(
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold
                                            ),
                                          ),
                                          Container(
                                            width: 180,
                                            child: Text(
                                              "${favAddress.placeName}",
                                              style: GoogleFonts.lato(
                                                  fontSize: 14,
                                                  color: TaxiAppColor.colorGrey
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      GestureDetector(
                                        onTap: (){

                                          Navigator.pushNamed(context, UpdateFavoriteAddress.id, arguments: favAddress).then((value){
                                            setState((){});
                                            if(value == "Updated"){
                                              showSnackBar(
                                                "Update Address Successfully",
                                              );
                                            }else{
                                              setState(() {});
                                            }

                                          });
                                        },
                                          child: SvgPicture.asset(
                                            edit, height: 25, width: 25,
                                            color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                          )
                                      ),
                                      SizedBox(width: 20,),
                                      GestureDetector(
                                        onTap: (){

                                          showDialog(
                                              context: context,
                                              builder: (context) => Dialog(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(10.0),
                                                ),
                                                elevation: 0.0,
                                                child: Container(
                                                  margin: EdgeInsets.all(0),
                                                  width: double.infinity,
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(10),
                                                  ),
                                                  child: Padding(
                                                    padding:  EdgeInsets.all(16.0),
                                                    child: SingleChildScrollView(
                                                      child: Column(
                                                        children: [

                                                          Text('Delete Address',
                                                            style: GoogleFonts.lato(
                                                                fontSize: 22.0,
                                                                fontWeight: FontWeight.bold
                                                            ),
                                                          ),
                                                          SizedBox(height: 15,),
                                                          BrandDivider(),

                                                          SizedBox(height: 15,),

                                                          Padding(
                                                            padding: EdgeInsets.all(8.0),
                                                            child: Text(
                                                              'are you sure you want to delete this Address',
                                                              textAlign: TextAlign.center,
                                                              style: GoogleFonts.lato(
                                                                color: TaxiAppColor.colorGrey
                                                              ),
                                                            ),
                                                          ),

                                                          SizedBox(height: 30,),

                                                          GestureDetector(
                                                            onTap: (){

                                                              // delete Favorite Address in sqlite database by id
                                                              setState(() {
                                                                db.deleteAddress(favAddress.id);
                                                              });

                                                              Navigator.pop(context);
                                                            },
                                                            child: Container(
                                                              height: 50,
                                                              width: MediaQuery.of(context).size.width,
                                                              decoration: BoxDecoration(
                                                                borderRadius: BorderRadius.circular(8),
                                                                border: Border.all(
                                                                  color: TaxiAppColor.colorPink,
                                                                  width: 2,
                                                                ),
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                children: [
                                                                  SvgPicture.asset(
                                                                      delete, height: 20,width: 20,
                                                                    color: TaxiAppColor.colorPink,
                                                                  ),
                                                                  SizedBox(width: 10,),
                                                                  Text(
                                                                    "Delete",
                                                                    style: GoogleFonts.lato(
                                                                        fontSize: 18,
                                                                        fontWeight: FontWeight.bold,
                                                                      color: TaxiAppColor.colorPink
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),


                                                          SizedBox(height: 10,),

                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ));

                                        },
                                          child: SvgPicture.asset(
                                            delete, height: 25, width: 25,
                                            color: TaxiAppColor.colorPink,
                                          )
                                      ),
                                    ],
                                  )
                                ],
                              )
                          );
                        }
                    );
                  }

                }
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkTextField : TaxiAppColor.colorDark,
        onPressed: () {
          Navigator.pushNamed(context, AddFavoriteAddressPage.id).then((value){
            setState((){});
            if(value == "Added"){
              showSnackBar(
                "Address Added Successfully",
              );
            }else{
              setState(() {});
            }

          });
        },
        child: Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
    );
  }
}


