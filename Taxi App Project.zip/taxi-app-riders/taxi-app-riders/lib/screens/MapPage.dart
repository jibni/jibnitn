import 'package:cab_rider/TaxiApp_Icons/TaxiApp_Icons.dart';
import 'package:cab_rider/Taxi_App_Color.dart';
import 'package:cab_rider/Theme/Theme.dart';
import 'package:cab_rider/datamodels/DropDownMenuModel.dart';
import 'package:cab_rider/datamodels/FavoriteAddress.dart';
import 'package:cab_rider/datamodels/directiondetails.dart';
import 'package:cab_rider/datamodels/nearbydriver.dart';
import 'package:cab_rider/datamodels/rider.dart';
import 'package:cab_rider/dataprovider/appdata.dart';
import 'package:cab_rider/globalvariable.dart';
import 'package:cab_rider/helpers/firehelper.dart';
import 'package:cab_rider/helpers/helpermethods.dart';
import 'package:cab_rider/rideVaribles.dart';
import 'package:cab_rider/screens/AboutUsPage.dart';
import 'package:cab_rider/screens/ContactUsPage.dart';
import 'package:cab_rider/screens/HowItWorksPage.dart';
import 'package:cab_rider/screens/MyTripsPage.dart';
import 'package:cab_rider/screens/SplashScreen.dart';
import 'package:cab_rider/screens/searchpage.dart';
import 'package:cab_rider/sqfLite/DatabaseHelper.dart';
import 'package:cab_rider/widgets/BrandDivier.dart';
import 'package:cab_rider/widgets/CollectPaymentDialog.dart';
import 'package:cab_rider/widgets/DropDownMenu.dart';
import 'package:cab_rider/widgets/NoDriverDialog.dart';
import 'package:cab_rider/widgets/ProgressDialog.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:async';

import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Taxi_App_Color.dart';
import 'FavoriteAddressPage.dart';

class MapPage extends StatefulWidget {
  static const String id = 'MapPage';

  @override
  _MapPageState createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> with TickerProviderStateMixin, WidgetsBindingObserver {

  final List<DropDownMenuModel> _personNumberList = [
    DropDownMenuModel(personNumber: '1 Person'),
    DropDownMenuModel(personNumber: '2 Person'),
    DropDownMenuModel(personNumber: '3 Person'),
  ];
  DropDownMenuModel _dropDownMenuModel = DropDownMenuModel(personNumber: '');
   List<DropdownMenuItem<DropDownMenuModel>> _personNumberModelDropdownList;
  List<DropdownMenuItem<DropDownMenuModel>> _buildPersonNumModelDropdown(
      List personList) {
    List<DropdownMenuItem<DropDownMenuModel>> items = [];
    for (DropDownMenuModel personNum in personList) {
      items.add(DropdownMenuItem(
        value: personNum,
        child: Row(
          children: [
            SvgPicture.asset(
              person,
              height: 20,width: 20,
              color: TaxiAppColor.colorGreyDark
            ),
            SizedBox(width: 10,),
            Text(
                personNum.personNumber,
              style: GoogleFonts.lato(
                color: TaxiAppColor.colorGreyDark
              ),
            ),
          ],
        ),
      ));
    }
    return items;
  }
  _onChangeFavouriteAddressModelDropdown(DropDownMenuModel dropDownMenuModel) {
    setState(() {
      _dropDownMenuModel = dropDownMenuModel;
    });
  }
  @override
  void initState() {
    db = new DatabaseHelper();
    _personNumberModelDropdownList =
        _buildPersonNumModelDropdown(_personNumberList);
    _dropDownMenuModel = _personNumberList[0];
    getRiderInfo();
    WidgetsBinding.instance.addObserver(this);
    loadMapStyles();
    super.initState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  getRiderInfo(){

    DatabaseReference riderRef = FirebaseDatabase.instance.reference().child('rider_users/${currentFirebaseUser.currentUser.uid}');
    riderRef.once().then((DataSnapshot snapshot){

      if(snapshot.value != null){
        currentRiderInfo = Rider.fromSnapshot(snapshot);
      }

    });
  }


  GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  double searchSheetHeight = 270;
  double rideDetailsSheetHeight = 0;
  double requestingSheetHeight = 0;
  double paySheetHeight = 0;
  double ratingDriverHeight = 0;
  double tripSheetHeight = 0;

  // rating
   double ratingDriverNumber;
  // show rate content
  double visible = 1;
  // hide ProgressBar
  double showProgressBar = 0;
  // show message done when rate data has been saved to firebase database
  double showMessageDone = 0;

  Completer<GoogleMapController> _controller = Completer();
   GoogleMapController mapController;

  final GoogleSignIn _googleSignIn = GoogleSignIn();

  List<LatLng> polylineCoordinates = [];
  Set<Polyline> _polylines = {};
  Set<Marker> _Markers = {};
  Set<Circle> _Circles = {};

   BitmapDescriptor nearbyIcon;

  var geoLocator = Geolocator();
   Position currentPosition;
   DirectionDetails tripDirectionDetails;

  String appState = 'NORMAL';

  bool drawerCanOpen = true;

   DatabaseReference rideRef;

   StreamSubscription<Event> rideSubscription;

   List<NearbyDriver> availableDrivers;

  bool nearbyDriversKeysLoaded = false;

  bool isRequestingLocationDetails = false;

  // sqlite Database
   DatabaseHelper db;


  void showSnackBar(String title) {
    final snackbar = SnackBar(
      content: Text(
        title,
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 15),
      ),
    );
    // ignore: deprecated_member_use
    scaffoldKey.currentState.showSnackBar(snackbar);
  }

  void setupPositionLocator() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;

    LatLng pos = LatLng(position.latitude, position.longitude);
    CameraPosition cp = new CameraPosition(target: pos, zoom: 20);
    mapController.animateCamera(CameraUpdate.newCameraPosition(cp));

    String address =
        await HelperMethods.searchCoordinateAddress(position, context);
    print("this is your address : " + address);

    startGeofireListener();
  }

  void showDetailSheet() async {
    await getDirection();

    setState(() {
      searchSheetHeight = 0;
      rideDetailsSheetHeight = 380;
      drawerCanOpen = false;
    });
  }


  void showRequestingSheet() {
    setState(() {
      rideDetailsSheetHeight = 0;
      requestingSheetHeight = 240;
      drawerCanOpen = true;
    });

    createRideRequest();
  }

  showTripSheet() {
    setState(() {
      requestingSheetHeight = 0;
      tripSheetHeight = 540;
    });
  }

  void createMarker() {
    if (nearbyIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context, size: Size(2, 2));
      BitmapDescriptor.fromAssetImage(
              imageConfiguration, 'images/car_android.png')
          .then((icon) {
        nearbyIcon = icon;
      });
    }
  }

  Future<void> signOut() async {
    FirebaseAuth _auth = FirebaseAuth.instance;
    await _auth.signOut();
  }


   SharedPreferences sharedPreferences;

  initSharedPreferences() async {
    sharedPreferences = await SharedPreferences.getInstance();
  }

   String _darkMapStyle;
   String _lightMapStyle;

  Future loadMapStyles() async {
    _darkMapStyle  = await rootBundle.loadString('mapStyle/DarkMode.json');
    _lightMapStyle = await rootBundle.loadString('mapStyle/LightMode.json');
  }

  // switch Dark / Light Mode of Google Map
  Future setMapStyle(ThemeProvider themeProvider) async {
    final controller = await _controller.future;
    if (themeProvider.checkDarkMode == true)
      controller.setMapStyle(_darkMapStyle);
    else
      controller.setMapStyle(_lightMapStyle);
  }


  @override
  Widget build(BuildContext context) {

    createMarker();

    ThemeProvider themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    setMapStyle(themeProvider);

    return Scaffold(
        key: scaffoldKey,
        drawer: Container(
          width: 280,
          child: Drawer(
            child: Container(
              color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
              child: ListView(
                padding: EdgeInsets.all(0),
                children: <Widget>[
                  Container(
                    color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                    height: 160,
                    child: DrawerHeader(
                      decoration: BoxDecoration(
                        color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                      ),
                      child: Row(
                        children: <Widget>[
                          ClipRRect(
                                  child: CachedNetworkImage(
                                    imageUrl:
                                        currentFirebaseUser.currentUser.photoURL,
                                    placeholder: (context, url) =>
                                        CircularProgressIndicator(
                                      backgroundColor: TaxiAppColor.colorDarkLight,
                                    ),
                                    height: 60,
                                    width: 60,
                                  ),
                                  borderRadius: BorderRadius.circular(100),
                                ),
                          SizedBox(
                            width: 15,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                width: 160,
                                child: Text(
                                  currentFirebaseUser.currentUser.displayName,
                                  style: GoogleFonts.lato(
                                      fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                  'I\'m a Rider',
                                style: GoogleFonts.lato(
                                  color: TaxiAppColor.colorGrey
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  BrandDivider(),
                  SizedBox(
                    height: 10,
                  ),
                  ListTile(
                    leading: SvgPicture.asset(car,height: 28,width: 28,color: TaxiAppColor.colorGrey,),
                    title: Text(
                      'My Trips',
                      style: GoogleFonts.lato(
                        fontWeight: FontWeight.bold,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        fontSize: 18
                      ),
                    ),
                    onTap: () {
                      Navigator.pushNamed(context, MyTripsPage.id);
                    },
                  ),
                  ListTile(
                    leading: SvgPicture.asset(favorite, height: 25,width: 25,color: TaxiAppColor.colorGrey,),
                    title: Text(
                      'Favorite Address',
                      style: GoogleFonts.lato(
                        fontWeight: FontWeight.bold,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        fontSize: 18
                      ),
                    ),
                    onTap: () {
                      Navigator.pushNamed(context, FavoriteAddressPage.id);
                    },
                  ),
                  ListTile(
                    leading: SvgPicture.asset(help,height: 25,width: 25,color: TaxiAppColor.colorGrey,),
                    title: Text(
                      'How it Work',
                      style: GoogleFonts.lato(
                        fontWeight: FontWeight.bold,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        fontSize: 18
                      ),
                    ),
                    onTap: () {
                      Navigator.pushNamed(context, HowItWorkPage.id);
                    },
                  ),
                  ListTile(
                    leading: SvgPicture.asset(contactUs,height: 28,width: 28,color: TaxiAppColor.colorGrey,),
                    title: Text(
                      'Contact us',
                      style: GoogleFonts.lato(
                        fontWeight: FontWeight.bold,
                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                        fontSize: 18
                      ),
                    ),
                    onTap: (){
                      Navigator.pushNamed(context, ContactUsPage.id);
                    },
                  ),
                  SizedBox(height: 40,),
                  ListTile(
                    leading: SvgPicture.asset(signOutIcon,height: 28,width: 28, color: TaxiAppColor.colorPink),
                    title: Text(
                      'Sign Out',
                      style: GoogleFonts.lato(
                          fontWeight: FontWeight.bold,
                          color: TaxiAppColor.colorPink,
                          fontSize: 18
                      ),
                    ),
                    onTap: () {

                      showDialog(
                          context: context,
                          builder: (context) => Dialog(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            elevation: 0.0,
                            child: Container(
                              margin: EdgeInsets.all(0),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Padding(
                                padding:  EdgeInsets.all(16.0),
                                child: SingleChildScrollView(
                                  child: Column(
                                    children: [

                                      Text('Sign Out',
                                        style: GoogleFonts.lato(
                                            fontSize: 22.0,
                                            fontWeight: FontWeight.bold
                                        ),
                                      ),
                                      SizedBox(height: 15,),
                                      BrandDivider(),

                                      SizedBox(height: 15,),

                                      Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Text(
                                          'are you sure you want signOut!',
                                          textAlign: TextAlign.center,
                                          style: GoogleFonts.lato(
                                              color: TaxiAppColor.colorGrey
                                          ),
                                        ),
                                      ),

                                      SizedBox(height: 30,),

                                      GestureDetector(
                                        onTap: () {

                                          signOut();
                                          signOutGoogle();
                                          Navigator.pop(context);
                                          Navigator.pushNamedAndRemoveUntil(
                                              context, SplashScreen.id, (route) => false);

                                        },
                                        child: Container(
                                          height: 50,
                                          width: MediaQuery.of(context).size.width,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(8),
                                            border: Border.all(
                                              width: 2,
                                              color: TaxiAppColor.colorPink
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              SvgPicture.asset(
                                                signOutIcon, height: 20,width: 20,
                                                color: TaxiAppColor.colorPink
                                              ),
                                              SizedBox(width: 10,),
                                              Text(
                                                "Sign Out",
                                                style: GoogleFonts.lato(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                  color: TaxiAppColor.colorPink
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),


                                      SizedBox(height: 10,),

                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ));
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        body: Stack(
          children: <Widget>[
            GoogleMap(
              padding: EdgeInsets.only(bottom: 50),
              mapType: MapType.normal,
              myLocationButtonEnabled: false,
              compassEnabled: false,
              initialCameraPosition: googlePlex,
              myLocationEnabled: true,
              zoomGesturesEnabled: true,
              zoomControlsEnabled: false,
              polylines: _polylines,
              markers: _Markers,
              circles: _Circles,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
                mapController = controller;

                setupPositionLocator();
              },
            ),

            ///MenuButton
            Positioned(
              top: 40,
              left: 20,
              child: GestureDetector(
                onTap: () {

                  if(drawerCanOpen){
                    scaffoldKey.currentState.openDrawer();
                  }
                  else{
                    resetApp();
                  }

                  },
                child: Row(
                  children: [
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black26.withOpacity(0.1),
                                blurRadius: 5.0,
                                spreadRadius: 0.5,
                                offset: Offset(
                                  0.7,
                                  0.7,
                                ))
                          ]),
                      child: CircleAvatar(
                          backgroundColor: (drawerCanOpen)
                              ? Colors.white
                              : TaxiAppColor.colorPink,
                          radius: 20,
                          child: (drawerCanOpen)
                              ? ClipRRect(
                               child: CachedNetworkImage(
                                 imageUrl:
                                 currentFirebaseUser.currentUser.photoURL,
                                 placeholder: (context, url) =>
                                  CircularProgressIndicator(
                                    backgroundColor: TaxiAppColor.colorDarkLight,
                                  ),
                              height: 60,
                              width: 60,
                            ),
                            borderRadius: BorderRadius.circular(100),
                          )
                              : Icon(
                                  Icons.cancel,
                                  size: 30,
                                  color: Colors.white,
                                )),
                    ),
                    SizedBox(
                      width: 12,
                    ),
                    Text(
                      (drawerCanOpen) ? "" : "Cancel",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        color: TaxiAppColor.colorPink
                      ),
                    )
                  ],
                ),
              ),
            ),

            ///Switch Theme Mode Button
            Positioned(
              top: 45,
              right: 85,
              child: GestureDetector(
                onTap: () async {
                  // switch Theme dark / light
                  setState(() {
                    themeProvider.swapTheme();
                  });

                },
                child: Container(
                    height: 50,
                    width: 50,
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                        borderRadius: BorderRadius.circular(50),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black26.withOpacity(0.1),
                              blurRadius: 5.0,
                              spreadRadius: 0.5,
                              offset: Offset(
                                0.7,
                                0.7,
                              ))
                        ]),
                    child: SvgPicture.asset(
                      themeProvider.checkDarkMode == true
                      ? light
                      : dark,
                      color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                    )
                ),
              ),
            ),

            ///SearchButton
            Positioned(
              top: 45,
              right: 20,
              child: GestureDetector(
                onTap: () async {

                  if (Provider.of<AppData>(context, listen: false)
                      .pickUpLocation ==
                      null) {
                    showSnackBar("Enable your Location First");
                  } else {
                    var response = await Navigator.pushNamed(
                        context, SearchPage.id);

                    if (response == 'getDirection') {
                      showDetailSheet();
                    }
                  }

                },
                child: Container(
                  height: 50,
                  width: 50,
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                      color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                      borderRadius: BorderRadius.circular(50),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26.withOpacity(0.1),
                            blurRadius: 5.0,
                            spreadRadius: 0.5,
                            offset: Offset(
                              0.7,
                              0.7,
                            ))
                      ]),
                  child: SvgPicture.asset(
                      search,
                    color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                  )
                ),
                ),
              ),

            /// Adresse Bar
            Positioned(
              bottom: 45,
              right: 20,
              left: 20,
              child: Container(
                  height: 65,
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26.withOpacity(0.1),
                            blurRadius: 5.0,
                            spreadRadius: 0.5,
                            offset: Offset(
                              0.7,
                              0.7,
                            ))
                      ]),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SvgPicture.asset(
                        destIcon, height: 25,width: 25,
                        color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      Flexible(
                        child: Text(
                          Provider.of<AppData>(context)
                          .pickUpLocation !=
                           null
                          ? Provider.of<AppData>(context)
                           .pickUpLocation
                            .placeName
                            : "Turn On your Location",
                           overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.lato(
                              fontSize: 17,
                            fontWeight: FontWeight.bold,
                            color: TaxiAppColor.colorGrey
                          )
                           ),
                      ),
                    ],
                  )
              ),
            ),

            /// Favorite Address Panel
            SlidingUpPanel(
              maxHeight: 500,
              minHeight: 30,
              parallaxEnabled: true,
              parallaxOffset: .5,
              panelSnapping: true,
              backdropEnabled: true,
              color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
              body: Container(),
              panelBuilder: (sc){
                return MediaQuery.removePadding(
                    context: context,
                    removeTop: true,
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 12.0,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              width: 30,
                              height: 5,
                              decoration: BoxDecoration(
                                  color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorGreyLite,
                                  borderRadius: BorderRadius.all(Radius.circular(12.0))),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 18.0,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              "Favorite Address",
                              style: GoogleFonts.lato(
                                fontWeight: FontWeight.bold,
                                fontSize: 26,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Expanded(
                          child: FutureBuilder(
                              future: db.getAllFavoriteAddress(),
                              builder: (context, AsyncSnapshot snapshot){
                                if(!snapshot.hasData){

                                  return Padding(
                                    padding: const EdgeInsets.only(top: 60),
                                    child: Text(
                                      "No Favorite Address yet",
                                      style: GoogleFonts.lato(
                                          fontSize: 18
                                      ),
                                    ),
                                  );
                                } else{

                                  return ListView.builder(
                                      controller: sc,
                                      itemCount: snapshot.data.length,
                                      itemBuilder: (context, int index){
                                        FavoriteAddress favAddress = FavoriteAddress.fromMap(snapshot.data[index]);
                                        return Container(
                                            padding: EdgeInsets.all(15),
                                            margin: EdgeInsets.only(bottom: 10, left: 20, right: 20, top: 5),
                                            decoration: BoxDecoration(
                                                color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : Colors.white,                                                borderRadius: BorderRadius.circular(10),
                                                boxShadow: [
                                                  BoxShadow(
                                                      color: Colors.black26.withOpacity(0.1),
                                                      blurRadius: 5.0,
                                                      spreadRadius: 0.5,
                                                      offset: Offset(
                                                        0.7,
                                                        0.7,
                                                      ))
                                                ]),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: [
                                                    SvgPicture.asset(
                                                      destIcon, height: 25,width: 25,
                                                      color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                                    ),
                                                    SizedBox(
                                                      width: 15,
                                                    ),
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          "${favAddress.favAddressName}",
                                                          style: GoogleFonts.lato(
                                                              fontSize: 18,
                                                              fontWeight: FontWeight.bold
                                                          ),
                                                        ),
                                                        Container(
                                                          width: 180,
                                                          child: Text(
                                                            "${favAddress.placeName}",
                                                            style: GoogleFonts.lato(
                                                                fontSize: 14,
                                                                color: TaxiAppColor.colorGrey
                                                            ),
                                                            overflow: TextOverflow.ellipsis,
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                                TextButton(
                                                  onPressed: () async{

                                                    await getDirectionFavAddress(favAddress);

                                                    setState(() {
                                                      searchSheetHeight = 0;
                                                      rideDetailsSheetHeight = 380;
                                                      drawerCanOpen = false;
                                                    });

                                                  },
                                                  child: Text(
                                                    "Let's Go",
                                                    style: GoogleFonts.lato(
                                                        fontWeight: FontWeight.bold,
                                                        color: TaxiAppColor.colorGreen,
                                                        fontSize: 18
                                                    ),
                                                  ),
                                                )
                                              ],
                                            )
                                        );
                                      }
                                  );
                                }

                              }
                          ),
                        )
                      ],
                    ));
              },
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20)),
            ),

            /// RideDetails Sheet
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: AnimatedSize(
                vsync: this,
                duration: new Duration(milliseconds: 150),
                child: Container(
                  decoration: BoxDecoration(
                    color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 15.0, // soften the shadow
                        spreadRadius: 0.5, //extend the shadow
                        offset: Offset(
                          0.7, // Move to right 10  horizontally
                          0.7, // Move to bottom 10 Vertically
                        ),
                      )
                    ],
                  ),
                  height: rideDetailsSheetHeight,
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 18),
                    child: Column(
                      children: <Widget>[
                        Text(
                          "New Trip",
                          style: GoogleFonts.lato(
                            fontSize: 23,
                            fontWeight: FontWeight.bold
                          ),
                        ),
                        SizedBox(height: 20,),
                        Padding(
                          padding: const EdgeInsets.only(left: 20,right: 20),
                          child: BrandDivider(),
                        ),
                        SizedBox(height: 20,),
                        Container(
                          width: double.infinity,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              children: <Widget>[
                                SvgPicture.asset(
                                  car,height: 50,width: 50,
                                  color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                ),
                                SizedBox(
                                  width: 12,
                                ),
                                Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      'Distance Trip',
                                      style: GoogleFonts.lato(
                                          fontSize: 18,
                                        fontWeight: FontWeight.bold
                                      ),
                                    ),
                                    Text(
                                      (tripDirectionDetails != null)
                                          ? tripDirectionDetails.distanceText
                                          : '',
                                      style: GoogleFonts.lato(
                                          fontSize: 16,
                                        color: TaxiAppColor.colorGrey
                                          ),
                                    )
                                  ],
                                ),
                                Expanded(child: Container()),
                                Column(
                                  children: [
                                    Text(
                                      "Trip Cost",
                                      style: GoogleFonts.lato(
                                          fontSize: 12,
                                        color: TaxiAppColor.colorGrey
                                      ),
                                    ),
                                    Text(
                                      (tripDirectionDetails != null)
                                          ? "US"+ '\$${HelperMethods.estimateFares(tripDirectionDetails)}'
                                          : '',
                                      style: GoogleFonts.lato(
                                          fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorGreen : TaxiAppColor.colorDark,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 10,),
                        DropDownMenu(
                         dropdownMenuItemList: _personNumberModelDropdownList,
                         onChanged: _onChangeFavouriteAddressModelDropdown,
                         value: _dropDownMenuModel,
                         isEnabled: true,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: Container(
                            height: 50,
                            width: MediaQuery.of(context).size.width,
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                                color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : TaxiAppColor.colorGreyLite,
                              borderRadius: BorderRadius.circular(8)
                            ),
                            child: Row(
                              children: [
                                SvgPicture.asset(dollar, height: 20, width: 20, color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorGreen : TaxiAppColor.colorDark),
                                SizedBox(width: 15,),
                                Text(
                                  "Pay A Cash",
                                  style: GoogleFonts.lato(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorGreen : TaxiAppColor.colorDark
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20,right: 20),
                          child: Row(
                            children: [
                              Expanded(
                                child: GestureDetector(
                                  onTap: (){
                                    showDialog(
                                        context: context,
                                        builder: (context) => Dialog(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          elevation: 0.0,
                                          child: Container(
                                            margin: EdgeInsets.all(0),
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(4),
                                            ),
                                            child: Padding(
                                              padding:  EdgeInsets.all(16.0),
                                              child: SingleChildScrollView(
                                                child: Column(
                                                  children: [
                                                    SizedBox(height: 10,),

                                                    Text('CANCEL TRIP', style: GoogleFonts.lato(fontSize: 20, fontWeight: FontWeight.bold),),
                                                    SizedBox(height: 20,),
                                                    BrandDivider(),
                                                    SizedBox(height: 20,),

                                                    Container(
                                                      width: 240,
                                                      child: Text(
                                                        'are you sure you want to Cancel this Trip?',
                                                        textAlign: TextAlign.center,
                                                        style: GoogleFonts.lato(
                                                            color: TaxiAppColor.colorGrey,
                                                            fontSize: 16
                                                        ),
                                                      ),
                                                    ),

                                                    SizedBox(height: 30,),

                                                    GestureDetector(
                                                      onTap: (){
                                                        resetApp();
                                                        Navigator.pop(context);
                                                      },
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(left: 20,right: 20),
                                                        child: Container(
                                                          height: 50,
                                                          width: MediaQuery.of(context).size.width,
                                                          decoration: BoxDecoration(
                                                              color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : TaxiAppColor.colorDark,
                                                              borderRadius: BorderRadius.circular(8)
                                                          ),
                                                          child: Center(
                                                            child: Text(
                                                              "Yes",
                                                              style: GoogleFonts.lato(
                                                                  fontSize: 18,
                                                                  fontWeight: FontWeight.bold,
                                                                color: Colors.white
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),

                                                    SizedBox(height: 10,),

                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ));
                                  },
                                  child: Container(
                                    height: 50,
                                    width: MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                        width: 2,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SvgPicture.asset(
                                            cancel, height: 20,width: 20,
                                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                        ),
                                        SizedBox(width: 10,),
                                        Text(
                                          "Cancel",
                                          style: GoogleFonts.lato(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                            color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width: 10,),
                              Expanded(
                                child: GestureDetector(
                                  onTap: (){
                                    setState(() {
                                      appState = 'REQUESTING';
                                    });
                                    showRequestingSheet();

                                    availableDrivers = FireHelper.nearbyDriverList;

                                    findDriver();
                                  },
                                  child: Container(
                                    height: 50,
                                    width: MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                        color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : TaxiAppColor.colorDark,
                                      borderRadius: BorderRadius.circular(8)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SvgPicture.asset(car, height: 20,width: 20,color: Colors.white,),
                                        SizedBox(width: 10,),
                                        Text(
                                          "Find Taxi",
                                          style: GoogleFonts.lato(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),

            /// Request Sheet
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: AnimatedSize(
                vsync: this,
                duration: new Duration(milliseconds: 150),
                curve: Curves.easeIn,
                child: Container(
                  decoration: BoxDecoration(
                    color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 15.0, // soften the shadow
                        spreadRadius: 0.5, //extend the shadow
                        offset: Offset(
                          0.7, // Move to right 10  horizontally
                          0.7, // Move to bottom 10 Vertically
                        ),
                      )
                    ],
                  ),
                  height: requestingSheetHeight,
                  child: Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(
                          height: 20,
                        ),
                        Text(
                          "Searching Taxi...",
                          style: GoogleFonts.lato(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            color: TaxiAppColor.colorGrey
                              ),
                        ),
                        SizedBox(height: 30,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              person, height: 30,width: 30,
                              color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                            ),
                            SizedBox(width: 10,),
                            SpinKitWave(
                              color: TaxiAppColor.colorPink,
                              size: 30,
                              itemCount: 15,
                              controller: AnimationController(
                                  vsync: this,
                                  duration: const Duration(milliseconds: 1500)),
                            ),
                            SizedBox(width: 10,),
                            SvgPicture.asset(
                              car, height: 40,width: 40,
                              color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 40,
                        ),
                        GestureDetector(
                          onTap: (){
                            cancelRequest();
                            resetApp();
                          },
                          child: Container(
                            height: 50,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                width: 2,
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                    cancel, height: 20,width: 20,
                                  color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                ),
                                SizedBox(width: 10,),
                                Text(
                                  "Cancel",
                                  style: GoogleFonts.lato(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            /// Trip Sheet
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: AnimatedSize(
                vsync: this,
                duration: new Duration(milliseconds: 150),
                curve: Curves.easeIn,
                child: Container(
                  decoration: BoxDecoration(
                    color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDark : Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 15.0, // soften the shadow
                        spreadRadius: 0.5, //extend the shadow
                        offset: Offset(
                          0.7, // Move to right 10  horizontally
                          0.7, // Move to bottom 10 Vertically
                        ),
                      )
                    ],
                  ),
                  height: tripSheetHeight,
                  child: Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(
                          height: 5,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 10,
                              width: 10,
                              decoration: BoxDecoration(
                                color: TaxiAppColor.colorGreen,
                                borderRadius: BorderRadius.circular(100)
                              ),
                            ),
                            SizedBox(width: 10,),
                            Text(
                              tripStatusDisplay,
                              textAlign: TextAlign.center,
                              style: GoogleFonts.lato(
                                  fontSize: 20,
                                fontWeight: FontWeight.bold
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        BrandDivider(),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  child: CachedNetworkImage(
                                    imageUrl: driverPhotoProfile,
                                    placeholder: (context, url) =>
                                        CircularProgressIndicator(
                                          backgroundColor: TaxiAppColor.colorDarkLight,
                                        ),
                                    height: 50,
                                    width: 50,
                                  ),
                                  borderRadius: BorderRadius.circular(100),
                                ),
                                SizedBox(width: 15,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      driverFullName,
                                      style: GoogleFonts.lato(
                                          fontSize: 18,
                                        fontWeight: FontWeight.bold
                                      ),
                                    ),
                                    SizedBox(height: 5,),
                                    Row(
                                      children: [
                                        SvgPicture.asset(star, height: 20,width: 20,color: TaxiAppColor.colorYellow,),
                                        SizedBox(width: 5,),
                                        Text(
                                          "4.5",
                                          style: GoogleFonts.lato(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: TaxiAppColor.colorGrey
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Text(
                                  "Trip Cost",
                                  style: GoogleFonts.lato(
                                      fontSize: 12,
                                      color: TaxiAppColor.colorGrey
                                  ),
                                ),
                                Text(
                                  (tripDirectionDetails != null)
                                      ? "US"+ '\$${HelperMethods.estimateFares(tripDirectionDetails)}'
                                      : "US"+ '\$0',
                                  style: GoogleFonts.lato(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorGreen : TaxiAppColor.colorDark,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 20,),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Row(
                            children: [
                              SvgPicture.asset(
                                car, height: 30,width: 30,
                                color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                              ),
                              SizedBox(width: 28,),
                              Text(
                                driverCarDetails,
                                style: GoogleFonts.lato(
                                  fontSize: 16,
                                  color: TaxiAppColor.colorGrey
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20,),
                        Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  cancelRequest();
                                  resetApp();
                                },
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                      width: 2,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SvgPicture.asset(
                                          cancel, height: 20,width: 20,
                                        color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                      ),
                                      SizedBox(width: 10,),
                                      Text(
                                        "Cancel",
                                        style: GoogleFonts.lato(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          color: themeProvider.checkDarkMode == true ? Colors.white : TaxiAppColor.colorDark,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 10,),
                            Expanded(
                              child: GestureDetector(
                                onTap: () async {
                                  // launch driver phone number
                                  var url = "tel:$driverPhoneNumber";
                                  if (await canLaunch(url)) {
                                    await launch(url);
                                  } else {
                                    throw 'Could not launch $url';
                                  }
                                },
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                      color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : TaxiAppColor.colorDark,
                                      borderRadius: BorderRadius.circular(8)
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SvgPicture.asset(call, height: 20,width: 20,color: Colors.white,),
                                      SizedBox(width: 10,),
                                      Text(
                                        "Call",
                                        style: GoogleFonts.lato(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        BrandDivider(),
                        SizedBox(
                          height: 20,
                        ),
                        visible == 1
                        ? Opacity(
                          opacity: visible,
                          child: Container(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  'HOW IS YOUR TRIP?',
                                  style: GoogleFonts.lato(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold
                                  ),
                                ),
                                SizedBox(
                                  height: 8,
                                ),
                                Padding(
                                  padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                                  child: Text(
                                    'your feedback will help us improve driving experience better.',
                                    textAlign: TextAlign.center,
                                    style: GoogleFonts.lato(
                                        fontSize: 14,
                                        color: TaxiAppColor.colorGrey
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 30,
                                ),
                                RatingBar.builder(
                                  initialRating: 3,
                                  minRating: 1,
                                  direction: Axis.horizontal,
                                  allowHalfRating: true,
                                  itemCount: 5,
                                  glowColor: TaxiAppColor.colorYellow,
                                  unratedColor: TaxiAppColor.colorGreyLite,
                                  itemPadding:
                                  EdgeInsets.symmetric(horizontal: 4.0),
                                  itemBuilder: (context, _) => Icon(
                                    Icons.star,
                                    color: TaxiAppColor.colorYellow,
                                  ),
                                  onRatingUpdate: (rating) {
                                    print(rating);
                                    if(rating == 0.5){
                                      setState(() {
                                        ratingDriverNumber = 0.5;
                                      });
                                    } else if(rating == 1.0){
                                      setState(() {
                                        ratingDriverNumber = 1.0;
                                      });
                                    } else if(rating == 1.5){
                                      setState(() {
                                        ratingDriverNumber = 1.5;
                                      });
                                    } else if(rating == 2.0){
                                      setState(() {
                                        ratingDriverNumber = 2.0;
                                      });
                                    } else if(rating == 2.5){
                                      setState(() {
                                        ratingDriverNumber = 2.5;
                                      });
                                    } else if(rating == 3.0){
                                      setState(() {
                                        ratingDriverNumber = 3.0;
                                      });
                                    } else if(rating == 3.5){
                                      setState(() {
                                        ratingDriverNumber = 3.5;
                                      });
                                    } else if(rating == 4.0){
                                      setState(() {
                                        ratingDriverNumber = 4.0;
                                      });
                                    } else if(rating == 4.5){
                                      setState(() {
                                        ratingDriverNumber = 4.5;
                                      });
                                    } else {
                                      setState(() {
                                        ratingDriverNumber = 5.0;
                                      });
                                    }
                                  },
                                ),
                                SizedBox(
                                  height: 30,
                                ),
                                Padding(
                                  padding:
                                  const EdgeInsets.only(left: 30, right: 30),
                                  child: GestureDetector(
                                    onTap: () async {

                                      setState(() {
                                        visible = 0;
                                        showProgressBar = 1;
                                      });

                                      DatabaseReference ratingByeUser = FirebaseDatabase.instance.reference()
                                          .child("driver_users/$driverID/ratings").push();
                                      Map ratingByUser = {
                                        "rating": ratingDriverNumber,
                                        "rider_name": currentFirebaseUser.currentUser.displayName,
                                        "rider_phone": currentFirebaseUser.currentUser.phoneNumber,
                                        "rider_photoProfile": currentFirebaseUser.currentUser.photoURL,
                                        "date_time": "${DateTime.now()}"
                                      };
                                      ratingByeUser.set(ratingByUser).whenComplete((){

                                        setState(() {
                                          showProgressBar = 0;
                                          showMessageDone = 1;
                                        });
                                      }
                                      );

                                    },
                                    child: Container(
                                      height: 50,
                                      width: MediaQuery.of(context).size.width,
                                      decoration: BoxDecoration(
                                          color: themeProvider.checkDarkMode == true ? TaxiAppColor.colorDarkLight : TaxiAppColor.colorDark,
                                          borderRadius: BorderRadius.circular(8)
                                      ),
                                      child: Center(
                                        child: Text(
                                          "Submit",
                                          style: GoogleFonts.lato(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        )
                        : showProgressBar == 1
                        ? Opacity(
                          opacity: showProgressBar,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 40),
                            child: SpinKitFadingCircle(
                            color: TaxiAppColor.colorDark,
                            size: 50,
                            controller: AnimationController(
                            vsync: this,
                            duration: const Duration(milliseconds: 1000)),
                            ),
                          ),
                        )
                        : Opacity(
                          opacity: showMessageDone,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 40),
                              child: Container(
                                alignment: Alignment.center,
                                child: Column(
                                  children: [
                                    SvgPicture.asset(done, height: 50, width: 50, color: TaxiAppColor.colorGreen,),
                                    SizedBox(height: 15,),
                                    Text(
                                      "Submit Successfuly",
                                      style: GoogleFonts.lato(
                                        fontSize: 20,
                                        color: TaxiAppColor.colorGreen
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ))
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ));
  }



  Future<void> getDirection() async {
    var pickup = Provider.of<AppData>(context, listen: false).pickUpLocation;
    var destination =
        Provider.of<AppData>(context, listen: false).dropOffLocation;

    var pickLatLng = LatLng(pickup.latitude, pickup.longitude);
    var destinationLatLng = LatLng(destination.latitude, destination.longitude);

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => ProgressDialog(
              status: 'Please wait...',
            ));

    var thisDetails =
        await HelperMethods.getDirectionDetails(pickLatLng, destinationLatLng);

    setState(() {
      tripDirectionDetails = thisDetails;
      fares = HelperMethods.estimateFares(tripDirectionDetails);
    });

    Navigator.pop(context);

    PolylinePoints polylinePoints = PolylinePoints();
    List<PointLatLng> results =
        polylinePoints.decodePolyline(thisDetails.encodedPoints);

    polylineCoordinates.clear();
    if (results.isNotEmpty) {
      // loop through all PointLatLng points and convert them
      // to a list of LatLng, required by the Polyline
      results.forEach((PointLatLng point) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
    }

    _polylines.clear();

    setState(() {
      Polyline polyline = Polyline(
        polylineId: PolylineId('polyid'),
        color: TaxiAppColor.colorPink,
        points: polylineCoordinates,
        jointType: JointType.round,
        width: 4,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        geodesic: true,
      );

      _polylines.add(polyline);
    });

    // make polyline to fit into the map

    LatLngBounds bounds;

    if (pickLatLng.latitude > destinationLatLng.latitude &&
        pickLatLng.longitude > destinationLatLng.longitude) {
      bounds =
          LatLngBounds(southwest: destinationLatLng, northeast: pickLatLng);
    } else if (pickLatLng.longitude > destinationLatLng.longitude) {
      bounds = LatLngBounds(
          southwest: LatLng(pickLatLng.latitude, destinationLatLng.longitude),
          northeast: LatLng(destinationLatLng.latitude, pickLatLng.longitude));
    } else if (pickLatLng.latitude > destinationLatLng.latitude) {
      bounds = LatLngBounds(
        southwest: LatLng(destinationLatLng.latitude, pickLatLng.longitude),
        northeast: LatLng(pickLatLng.latitude, destinationLatLng.longitude),
      );
    } else {
      bounds =
          LatLngBounds(southwest: pickLatLng, northeast: destinationLatLng);
    }

    mapController.animateCamera(CameraUpdate.newLatLngBounds(bounds, 70));

    Marker pickupMarker = Marker(
      markerId: MarkerId('pickup'),
      position: pickLatLng,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      infoWindow: InfoWindow(title: pickup.placeName, snippet: 'My Location'),
    );

    Marker destinationMarker = Marker(
      markerId: MarkerId('destination'),
      position: destinationLatLng,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      infoWindow:
          InfoWindow(title: destination.placeName, snippet: 'Destination'),
    );

    setState(() {
      _Markers.add(pickupMarker);
      _Markers.add(destinationMarker);
    });

    Circle pickupCircle = Circle(
      circleId: CircleId('pickup'),
      strokeColor: Colors.green,
      strokeWidth: 3,
      radius: 12,
      center: pickLatLng,
    );

    Circle destinationCircle = Circle(
      circleId: CircleId('destination'),
      strokeWidth: 3,
      radius: 12,
      center: destinationLatLng,
    );

    setState(() {
      _Circles.add(pickupCircle);
      _Circles.add(destinationCircle);
    });
  }

  Future<void> getDirectionFavAddress(FavoriteAddress favoriteAddress) async {
    var pickup = Provider.of<AppData>(context, listen: false).pickUpLocation;


    var pickLatLng = LatLng(pickup.latitude, pickup.longitude);
    var destinationLatLng = LatLng(favoriteAddress.latitude, favoriteAddress.longitude);

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => ProgressDialog(
          status: 'Please wait...',
        ));

    var thisDetails =
    await HelperMethods.getDirectionDetails(pickLatLng, destinationLatLng);

    setState(() {
      tripDirectionDetails = thisDetails;
      fares = HelperMethods.estimateFares(tripDirectionDetails);
    });

    Navigator.pop(context);

    PolylinePoints polylinePoints = PolylinePoints();
    List<PointLatLng> results =
    polylinePoints.decodePolyline(thisDetails.encodedPoints);

    polylineCoordinates.clear();
    if (results.isNotEmpty) {
      // loop through all PointLatLng points and convert them
      // to a list of LatLng, required by the Polyline
      results.forEach((PointLatLng point) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
    }

    _polylines.clear();

    setState(() {
      Polyline polyline = Polyline(
        polylineId: PolylineId('polyid'),
        color: TaxiAppColor.colorPink,
        points: polylineCoordinates,
        jointType: JointType.round,
        width: 4,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        geodesic: true,
      );

      _polylines.add(polyline);
    });

    // make polyline to fit into the map

    LatLngBounds bounds;

    if (pickLatLng.latitude > destinationLatLng.latitude &&
        pickLatLng.longitude > destinationLatLng.longitude) {
      bounds =
          LatLngBounds(southwest: destinationLatLng, northeast: pickLatLng);
    } else if (pickLatLng.longitude > destinationLatLng.longitude) {
      bounds = LatLngBounds(
          southwest: LatLng(pickLatLng.latitude, destinationLatLng.longitude),
          northeast: LatLng(destinationLatLng.latitude, pickLatLng.longitude));
    } else if (pickLatLng.latitude > destinationLatLng.latitude) {
      bounds = LatLngBounds(
        southwest: LatLng(destinationLatLng.latitude, pickLatLng.longitude),
        northeast: LatLng(pickLatLng.latitude, destinationLatLng.longitude),
      );
    } else {
      bounds =
          LatLngBounds(southwest: pickLatLng, northeast: destinationLatLng);
    }

    mapController.animateCamera(CameraUpdate.newLatLngBounds(bounds, 70));

    Marker pickupMarker = Marker(
      markerId: MarkerId('pickup'),
      position: pickLatLng,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      infoWindow: InfoWindow(title: pickup.placeName, snippet: 'My Location'),
    );

    Marker destinationMarker = Marker(
      markerId: MarkerId('destination'),
      position: destinationLatLng,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      infoWindow:
      InfoWindow(title: favoriteAddress.placeName, snippet: 'Destination'),
    );

    setState(() {
      _Markers.add(pickupMarker);
      _Markers.add(destinationMarker);
    });

    Circle pickupCircle = Circle(
      circleId: CircleId('pickup'),
      strokeColor: Colors.green,
      strokeWidth: 3,
      radius: 12,
      center: pickLatLng,
    );

    Circle destinationCircle = Circle(
      circleId: CircleId('destination'),
      strokeWidth: 3,
      radius: 12,
      center: destinationLatLng,
    );

    setState(() {
      _Circles.add(pickupCircle);
      _Circles.add(destinationCircle);
    });
  }


  void startGeofireListener() {
    Geofire.initialize('driversAvailable');
    Geofire.queryAtLocation(
            currentPosition.latitude, currentPosition.longitude, 20)
        .listen((map) {
      if (map != null) {
        var callBack = map['callBack'];

        switch (callBack) {
          case Geofire.onKeyEntered:
            NearbyDriver nearbyDriver = NearbyDriver(longitude: 0, key: '', latitude: 0);
            nearbyDriver.key = map['key'];
            nearbyDriver.latitude = map['latitude'];
            nearbyDriver.longitude = map['longitude'];
            FireHelper.nearbyDriverList.add(nearbyDriver);

            if (nearbyDriversKeysLoaded) {
              updateDriversOnMap();
            }
            break;

          case Geofire.onKeyExited:
            FireHelper.removeFromList(map['key']);
            updateDriversOnMap();
            break;

          case Geofire.onKeyMoved:
            // Update your key's location

            NearbyDriver nearbyDriver = NearbyDriver(latitude: 0, longitude: 0, key: '');
            nearbyDriver.key = map['key'];
            nearbyDriver.latitude = map['latitude'];
            nearbyDriver.longitude = map['longitude'];

            FireHelper.updateNearbyLocation(nearbyDriver);
            updateDriversOnMap();
            break;

          case Geofire.onGeoQueryReady:
            nearbyDriversKeysLoaded = true;
            updateDriversOnMap();
            break;
        }
      }
    });
  }

  void updateDriversOnMap() {
    setState(() {
      _Markers.clear();
    });

    Set<Marker> tempMarkers = Set<Marker>();

    for (NearbyDriver driver in FireHelper.nearbyDriverList) {
      LatLng driverPosition = LatLng(driver.latitude, driver.longitude);
      Marker thisMarker = Marker(
        markerId: MarkerId('driver${driver.key}'),
        position: driverPosition,
        icon: nearbyIcon,
        rotation: HelperMethods.generateRandomNumber(360),
      );

      tempMarkers.add(thisMarker);
    }

    setState(() {
      _Markers = tempMarkers;
    });
  }

  void createRideRequest() {

    rideRef = FirebaseDatabase.instance.reference().child('rideRequest').push();

    // save trip info to passenger
    DatabaseReference tripRider = FirebaseDatabase.instance
        .reference()
        .child("rider_users/${currentFirebaseUser.currentUser.uid}/myTrips");


    var pickup = Provider.of<AppData>(context, listen: false).pickUpLocation;
    var destination =
        Provider.of<AppData>(context, listen: false).dropOffLocation;

    Map pickupMap = {
      'latitude': pickup.latitude.toString(),
      'longitude': pickup.longitude.toString(),
    };

    Map destinationMap = {
      'latitude': destination.latitude.toString(),
      'longitude': destination.longitude.toString(),
    };

    Map rideReq = {
      'created_at': DateTime.now().toString(),
      'rider_name': currentFirebaseUser.currentUser.displayName,
      'rider_phone': currentRiderInfo.phoneNumber,
      'rider_Photo': currentFirebaseUser.currentUser.photoURL,
      'person_number': _dropDownMenuModel.personNumber,
      'pickup_address': pickup.placeName,
      'destination_address': destination.placeName,
      'location': pickupMap,
      'destination': destinationMap,
      'payment_method': 'Cash',
      'tripCost': '$fares',
      'driver_id': 'waiting',
    };

    rideRef.set(rideReq);

    rideSubscription = rideRef.onValue.listen((event) async {
      //check for null snapshot
      if (event.snapshot.value == null) {
        return;
      }

      //get Driver ID
      if (event.snapshot.value['driver_id'] != null) {
        setState(() {
          driverID = event.snapshot.value['driver_id'].toString();
        });
      }

      //get car details
      if (event.snapshot.value['car_details'] != null) {
        setState(() {
          driverCarDetails = event.snapshot.value['car_details'].toString();
        });
      }

      //get driver Photo Profile
      if (event.snapshot.value['driver_photoProfile'] != null) {
        setState(() {
          driverPhotoProfile = event.snapshot.value['driver_photoProfile'].toString();
        });
      }


      // get driver name
      if (event.snapshot.value['driver_name'] != null) {
        setState(() {
          driverFullName = event.snapshot.value['driver_name'].toString();
        });
      }

      // get driver phone number
      if (event.snapshot.value['driver_phone'] != null) {
        setState(() {
          driverPhoneNumber = event.snapshot.value['driver_phone'].toString();
        });
      }

      //get and use driver location updates
      if (event.snapshot.value['driver_location'] != null) {
        double driverLat = double.parse(
            event.snapshot.value['driver_location']['latitude'].toString());
        double driverLng = double.parse(
            event.snapshot.value['driver_location']['longitude'].toString());
        LatLng driverLocation = LatLng(driverLat, driverLng);

        if (status == 'accepted') {
          updateToPickup(driverLocation);
        } else if (status == 'ontrip') {
          updateToDestination(driverLocation);
        } else if (status == 'arrived') {
          setState(() {
            tripStatusDisplay = 'Driver has arrived';
          });
        }
      }

      if (event.snapshot.value['status'] != null) {
        status = event.snapshot.value['status'].toString();
      }

      if (status == 'accepted') {
        showTripSheet();
        Geofire.stopListener();
        removeGeofireMarkers();
      }



      if (status == 'ended') {
        if (event.snapshot.value['tripCost'] != null) {

          Map saveTripRider = {
            'created_at': DateTime.now().toString(),
            'driver_name': driverFullName,
            'driver_photoProfile': driverPhotoProfile,
            'pickup_address': pickup.placeName,
            'destination_address': destination.placeName,
            'TripCost': '$fares',
          };

          tripRider.push().set(saveTripRider);

          setState(() {
              showDialog(
                  context: context,
                  builder: (context) => CollectPayment(
                        fares: fares,
                        paymentMethod: "Cash",
                      ));
            tripSheetHeight = 0;
          });
            rideRef.onDisconnect();

            rideRef = null;

            rideSubscription.cancel();

            rideSubscription = null ;

          resetApp();

        }
      }
    });
  }

  void removeGeofireMarkers() {
    setState(() {
      _Markers.removeWhere((m) => m.markerId.value.contains('driver'));
    });
  }

  void updateToPickup(LatLng driverLocation) async {
    if (!isRequestingLocationDetails) {
      isRequestingLocationDetails = true;

      var positionLatLng =
          LatLng(currentPosition.latitude, currentPosition.longitude);

      var thisDetails = await HelperMethods.getDirectionDetails(
          driverLocation, positionLatLng);

      if (thisDetails == null) {
        return;
      }

      setState(() {
        tripStatusDisplay = 'Driver is Arriving - ${thisDetails.durationText}';
      });

      isRequestingLocationDetails = false;
    }
  }

  void updateToDestination(LatLng driverLocation) async {
    if (!isRequestingLocationDetails) {
      isRequestingLocationDetails = true;

      var destination =
          Provider.of<AppData>(context, listen: false).dropOffLocation;

      var destinationLatLng =
          LatLng(destination.latitude, destination.longitude);

      var thisDetails = await HelperMethods.getDirectionDetails(
          driverLocation, destinationLatLng);

      if (thisDetails == null) {
        return;
      }

      setState(() {
        tripStatusDisplay =
            'Driving to Destination - ${thisDetails.durationText}';
      });

      isRequestingLocationDetails = false;
    }
  }

  void cancelRequest() {
    rideRef.remove();

    setState(() {
      appState = 'NORMAL';
    });
  }

  resetApp() {
    setState(() {
      polylineCoordinates.clear();
      _polylines.clear();
      _Markers.clear();
      _Circles.clear();
      rideDetailsSheetHeight = 0;
      requestingSheetHeight = 0;
      tripSheetHeight = 0;
      paySheetHeight = 0;
      ratingDriverHeight = 0;
      drawerCanOpen = true;

      status = '';
      driverFullName = '';
      driverPhoneNumber = '';
      driverCarDetails = '';
      tripStatusDisplay = 'Driver is Arriving';

    });

    setupPositionLocator();
  }

  void noDriverFound() {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => NoDriverDialog());
  }

  void findDriver() {
    if (availableDrivers.length == 0) {
      cancelRequest();
      resetApp();
      noDriverFound();
      return;
    }

    var driver = availableDrivers[0];

    notifyDriver(driver);

    availableDrivers.removeAt(0);

    print("Driver Key : ${driver.key}");
  }

  void signOutGoogle() async {
    await _googleSignIn.signOut();

    print("User Signed Out");
  }

  void notifyDriver(NearbyDriver driver) {
    DatabaseReference driverTripRef = FirebaseDatabase.instance
        .reference()
        .child('driver_users/${driver.key}/newtrip');
    driverTripRef.set(rideRef.key);

    // Get and notify driver using token
    DatabaseReference tokenRef = FirebaseDatabase.instance
        .reference()
        .child('driver_users/${driver.key}/token');

    tokenRef.once().then((DataSnapshot snapshot) {
      if (snapshot.value != null) {
        String token = snapshot.value.toString();

        // send notification to selected driver
        HelperMethods.sendNotification(token, context, rideRef.key);
      } else {
        return;
      }

      const oneSecTick = Duration(seconds: 1);

      var timer = Timer.periodic(oneSecTick, (timer) {
        // stop timer when ride request is cancelled;
        if (appState != 'REQUESTING') {
          driverTripRef.set('cancelled');
          driverTripRef.onDisconnect();
          timer.cancel();
          driverRequestTimeout = 30;
        }

        driverRequestTimeout--;

        // a value event listener for driver accepting trip request
        driverTripRef.onValue.listen((event) {
          // confirms that driver has clicked accepted for the new trip request
          if (event.snapshot.value.toString() == 'accepted') {
            driverTripRef.onDisconnect();
            timer.cancel();
            driverRequestTimeout = 30;
          }
        });

        if (driverRequestTimeout == 0) {
          //informs driver that ride has timed out
          driverTripRef.set('timeout');
          driverTripRef.onDisconnect();
          driverRequestTimeout = 30;
          timer.cancel();

          //select the next closest driver
          findDriver();
        }
      });
    });
  }
}


