import 'package:cab_rider/datamodels/address.dart';
import 'package:flutter/cupertino.dart';

class AppData extends ChangeNotifier{

   Address pickUpLocation;
   Address dropOffLocation;

  int ratingCnt = 0;

  void ratingCount(int newRatingCount){
    ratingCnt = newRatingCount;
    notifyListeners();
  }

  void updatePickupAddress(Address pickUpAddress){
    pickUpLocation = pickUpAddress;
    notifyListeners();
  }

  void updateDestinationAddress(Address dropOffAddress){
    dropOffLocation = dropOffAddress;
    notifyListeners();
  }
}